package w1t1;

public class HalloWelt {

	public static void main(String[] args) {
		while(true) {
		String s = "Hallo Welt";
		System.out.println(s);
		}
	}

	
}
